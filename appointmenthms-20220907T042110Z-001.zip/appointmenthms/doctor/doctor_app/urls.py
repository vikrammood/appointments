
from django.urls import path
from .views import  LoginView, DoctorView, LogoutView


urlpatterns = [
   # path('register', RegisterView.as_view()),
   path('login', LoginView.as_view()),
   path('doctor', DoctorView.as_view()),
   path('logout', LogoutView.as_view()),
]