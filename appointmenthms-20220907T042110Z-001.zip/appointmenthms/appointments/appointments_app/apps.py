from django.apps import AppConfig


class AppointmentsAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'appointments_app'
